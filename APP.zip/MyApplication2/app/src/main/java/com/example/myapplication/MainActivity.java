package com.example.myapplication;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;

import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements  SensorEventListener{
    Button lightindex;
    private TextView xTextacc, yTextacc, zTextacc;
    private TextView xTextgyro, yTextgyro, zTextgyro;
    private TextView xTexttemp;
    private TextView xTextLight;
    private TextView xTextprox;
    private Sensor ACC;
    private Sensor GYRO;
    private Sensor TEMP;
    private Sensor LIGHT;
    private Sensor PROX;
    private SensorManager SM;
    int mColor;

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            xTextacc.setText("X: " + event.values[0] + "m/s^2");
            yTextacc.setText("Y: " + event.values[1] + "m/s^2");
            zTextacc.setText("Z: " + event.values[2] + "m/s^2");
        }
        if (event.sensor.getType() == Sensor.TYPE_GYROSCOPE) {
            xTextgyro.setText("X: " + event.values[0] + "rad/s");
            yTextgyro.setText("Y: " + event.values[1] + "rad/s");
            zTextgyro.setText("Z: " + event.values[2] + "rad/s");
        }
        if (event.sensor.getType() == Sensor.TYPE_AMBIENT_TEMPERATURE){
            xTexttemp.setText("Temperature: "+event.values[0]+ "degree C");
        }
        if (event.sensor.getType() == Sensor.TYPE_LIGHT){
            xTextLight.setText("Brightness: "+event.values[0]+ "lx");
            if ((event.values[0]<4000.0f)&(event.values[0]>=0.0f)) {
                if(mColor!= Color.BLACK){
                    mColor= Color.BLACK;
                    lightindex.setBackgroundColor(Color.BLACK);
                }}
            else if ((event.values[0]<8000.0f)&(event.values[0]>4000.0f)) {
                if(mColor!= Color.parseColor("#2f4f4f")){
                    mColor= Color.parseColor("#2f4f4f");
                    lightindex.setBackgroundColor(Color.parseColor("#2f4f4f"));
                }
            }
            else if ((event.values[0]<12000.0f)&(event.values[0]>8000.0f)) {
                if(mColor!= Color.parseColor("#696969")){
                    mColor= Color.parseColor("#696969");
                    lightindex.setBackgroundColor(Color.parseColor("#696969"));
                }
            }
            else if ((event.values[0]<16000.0f)&(event.values[0]>12000.0f)) {
                if (mColor != Color.parseColor("#708090")) {
                    mColor = Color.parseColor("#708090");
                    lightindex.setBackgroundColor(Color.parseColor("#708090"));
                }
            }
            else if ((event.values[0]<20000.0f)&(event.values[0]>16000.0f)) {
                if(mColor!= Color.parseColor("#778899")){
                    mColor= Color.parseColor("#778899");
                    lightindex.setBackgroundColor(Color.parseColor("#778899"));
                }
            }
            else if ((event.values[0]<24000.0f)&(event.values[0]>20000.0f)) {
                if(mColor!= Color.parseColor("#bebebe")){
                    mColor= Color.parseColor("#bebebe");
                    lightindex.setBackgroundColor(Color.parseColor("#bebebe"));
                }
            }
            else if ((event.values[0]<28000.0f)&(event.values[0]>24000.0f)) {
                if(mColor!= Color.parseColor("#d3d3d3")){
                    mColor= Color.parseColor("#d3d3d3");
                    lightindex.setBackgroundColor(Color.parseColor("#d3d3d3"));
                }
            }
                else{
                    if(mColor!= Color.WHITE){
                        mColor= Color.WHITE;
                        lightindex.setBackgroundColor(Color.WHITE);
                    }
                }
            }

        if (event.sensor.getType() == Sensor.TYPE_PROXIMITY){
            xTextprox.setText("The object is "+event.values[0]+ " cm away");
        }
    }
    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        //Not in use
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {
        //Not in use
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Create our sensor Manager

        SM=(SensorManager)getSystemService(SENSOR_SERVICE);

        //Accelerometer Sensor

        ACC = SM.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        GYRO= SM.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        TEMP= SM.getDefaultSensor(Sensor.TYPE_AMBIENT_TEMPERATURE);
        LIGHT=SM.getDefaultSensor(Sensor.TYPE_LIGHT);
        PROX= SM.getDefaultSensor(Sensor.TYPE_PROXIMITY);
        //Register sensor Listener

        SM.registerListener(this,ACC,SensorManager.SENSOR_DELAY_NORMAL);
        SM.registerListener(this,GYRO,SensorManager.SENSOR_DELAY_NORMAL);
        SM.registerListener(this,TEMP,SensorManager.SENSOR_DELAY_NORMAL);
        SM.registerListener(this,LIGHT,SensorManager.SENSOR_DELAY_NORMAL);
        SM.registerListener(this,PROX,SensorManager.SENSOR_DELAY_NORMAL);

        //Assign TextView

        xTextacc=(TextView)findViewById(R.id.xTextacc);
        yTextacc=(TextView)findViewById(R.id.yTextacc);
        zTextacc=(TextView)findViewById(R.id.zTextacc);

        xTextgyro=(TextView)findViewById(R.id.xTextgyro);
        yTextgyro=(TextView)findViewById(R.id.yTextgyro);
        zTextgyro=(TextView)findViewById(R.id.zTextgyro);

        xTexttemp=(TextView)findViewById(R.id.xTexttemp);

        xTextLight=(TextView)findViewById(R.id.xTextLight);

        xTextprox=(TextView)findViewById(R.id.xTextprox);

        lightindex=(Button)findViewById(R.id.lightindex);




    }




}
//Chen Chen 50180161
//https://www.youtube.com/watch?v=YrI2pCZC8cc
//http://amarandroid.blogspot.com/2013/04/hexadecimal-color-codes-list-using-in.html
//https://alvinalexander.com/source-code/android/how-create-color-hexadecimal-color-string-android
//https://stackoverflow.com/questions/16150566/proximity-sensor-to-change-button-color